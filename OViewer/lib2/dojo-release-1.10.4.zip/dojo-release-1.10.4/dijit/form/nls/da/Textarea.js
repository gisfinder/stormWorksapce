//>>built
define("dijit/form/nls/da/Textarea",({iframeEditTitle:"redigeringsområde",iframeFocusTitle:"ramme om redigeringsområde"}));
