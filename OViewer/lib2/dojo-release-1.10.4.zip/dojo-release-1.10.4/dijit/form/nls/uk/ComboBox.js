//>>built
define("dijit/form/nls/uk/ComboBox",({previousMessage:"Попередні варіанти",nextMessage:"Додаткові варіанти"}));
