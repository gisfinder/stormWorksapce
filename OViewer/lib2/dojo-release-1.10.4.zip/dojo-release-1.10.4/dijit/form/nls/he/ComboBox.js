//>>built
define("dijit/form/nls/he/ComboBox",({previousMessage:"האפשרויות הקודמות",nextMessage:"אפשרויות נוספות"}));
